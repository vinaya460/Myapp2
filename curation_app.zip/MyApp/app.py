from flask import Flask, render_template, request, send_file
import sqlite3 as sql
import pandas as pd


app = Flask(__name__)



@app.route('/')
def home():
    return render_template('home.html')


@app.route('/curation')
def curate_job():
    return render_template('curation.html')


@app.route('/curation', methods=['POST','GET'])
def curation():
    if request.method == 'POST':
        try:
            ResourceName = request.form['ColumnName']
            Resource = request.form['CurationType']
           
            print(ResourceName)
            print(Resource)


            if ResourceName == "":
                ResourceName = "null"
           

            with sql.connect("database.db") as con:
                cur = con.cursor()

                cur.execute("INSERT INTO students (name) VALUES('anhyui')" )

                con.commit()
                msg = "Thank You training the job" 
                msg += '\n' 
                
        except:
            con.rollback()
            msg = "error in insert operation"

        finally:
            return render_template("result.html", msg=msg)
            con.close()




       
@app.route('/upload')
def upload():
   return render_template('upload.html')
	
@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      print(f)
      f.save('/Users/ishaan/Downloads/MyApp/test2.csv')
      df=pd.read_csv('/Users/ishaan/Downloads/MyApp/test2.csv')
      print(df)
      return render_template("result.html", msg='fileuploaded sucessfully')

@app.route('/Jobs')
def Jobs_Submission():
    return render_template('jobs.html')

@app.route('/Jobs', methods=['POST','GET'])
def Jobs():
    if request.method == 'POST':
        try:
            ResourceName = request.form['ResourceName']
            
            print(ResourceName)

            if ResourceName == "":
                ResourceName = "null"
           

            with sql.connect("database.db") as con:
                cur = con.cursor()

                cur.execute("INSERT INTO students (name) VALUES('anhyui')" )

                con.commit()
                msg = "Job is submitted" 
                msg += '\n' 
                
        except:
            con.rollback()
            msg = "error in insert operation"

        finally:
            return render_template("result.html", msg=msg)
            con.close()


@app.route("/Reports")
def Reports():
    return render_template('Reports.html')
	
@app.route('/download_file')
def download_file():
    download_file=send_file('/Users/ishaan/Downloads/Myapp/frt.csv', as_attachment=True)
    print(download_file)
    return download_file


@app.route('/data')
def data():
    user = request.args.get('node')
    user1 = request.args.get('want')
    if user != "":
        return user + " " + user1





if __name__ == '__main__':
    app.run()